<template>
	<div class="container">
		<!-- <component-one />
		<component-two /> -->

		<component-with-data />
	</div>
</template>

<script>
	/* eslint-disable */
	// import ComponentOne from "./components/2_multi-components/ComponentOne.vue";
	// import ComponentTwo from "./components/2_multi-components/ComponentTwo.vue";

	// import ComponentOne from "./components/3_components-with-inline-style/ComponentOne.vue";
	// import ComponentTwo from "./components/3_components-with-inline-style/ComponentTwo.vue";

	// import ComponentOne from "./components/4_components-with-css-scoped/ComponentOne.vue";
	// import ComponentTwo from "./components/4_components-with-css-scoped/ComponentTwo.vue";

	// import ComponentOne from "./components/5_components-with-css-modules/ComponentOne.vue";
	// import ComponentTwo from "./components/5_components-with-css-modules/ComponentTwo.vue";

	// import ComponentOne from "./components/6_external-css/comp-one/ComponentOne.vue";
	// import ComponentTwo from "./components/6_external-css/comp-two/ComponentTwo.vue";

	import ComponentOne from "./components/7_external-css-as-css-module/comp-one/ComponentOne.vue";
	import ComponentTwo from "./components/7_external-css-as-css-module/comp-two/ComponentTwo.vue";

	import ComponentWithData from "./components/8_comp-data/ComponentWithData.vue";

	export default {
		components: { ComponentOne, ComponentTwo, ComponentWithData },
	};
</script>