<template>
	<h1 class="text-primary">Hello World</h1>
</template>

<script>
	export default {
		name: "Hello",
	};
</script>

<style>
</style>