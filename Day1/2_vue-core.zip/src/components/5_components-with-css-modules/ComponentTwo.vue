<template>
	<div>
		<h1 class="text-success">Hello from Component Two</h1>
		<h2 v-bind:class="$style.card">From Component Two</h2>
	</div>
</template>

<script>
	export default {
		name: "ComponentTwo",
	};
</script>

<style module>
	.card {
		margin: 1em;
		padding-left: 0;
		border: 2px dashed green;
	}
</style>