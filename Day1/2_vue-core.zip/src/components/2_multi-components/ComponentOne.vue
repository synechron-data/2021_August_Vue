<template>
	<h1 class="text-info">Hello from Component One</h1>
</template>

<script>
	export default {
		name: "ComponentOne",
	};
</script>