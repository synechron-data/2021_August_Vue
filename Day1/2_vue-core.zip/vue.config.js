module.exports = {
    devServer: {
        open: true
    },
    // runtimeCompiler: true
};