import productInMemoryClient from "../services/product-in-memory-client";

const productsDataMixin = {
    data() {
        return {
            productsData: productInMemoryClient.getAllProducts()
        }
    },
};

export default productsDataMixin;