<template>
	<div class="outerdiv">
		<div class="innerdiv">
			<h2 class="text-warning">Please Select a product</h2>
		</div>
	</div>
</template>

<script>
	export default {
		name: "ProductNotSelectedComponent",
	};
</script>