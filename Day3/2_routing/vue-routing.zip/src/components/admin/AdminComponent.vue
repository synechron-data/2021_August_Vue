<template>
	<div>
		<h1 class="text-info">Admin Component</h1>
		<h4 class="text-success">Welcome, you are an authenticated user.</h4>
		<hr class="mt-5" />
		<h3 class="text-info">{{ message }}</h3>
		<Table :items="products" />
	</div>
</template>

<script>
	import Table from "../common/datatable/Table.vue";
	import productApiClient from "../../services/product-api-client";

	export default {
		components: { Table },
		name: "AdminComponent",
		beforeMount() {
			productApiClient
				.getAllProducts()
				.then((data) => {
					this.products = [...data];
					this.message = "";
				})
				.catch((eMsg) => {
					this.message = eMsg;
				});
		},
		data: function () {
			return {
				products: [],
				message: "Loading Data, please wait...",
			};
		},
	};
</script>