import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue';
import fetchIntercept from 'fetch-intercept';

import Vue from 'vue'

import App from './App.vue';
import { ValidationObserver, ValidationProvider, extend, localize } from 'vee-validate';
import en from 'vee-validate/dist/locale/en.json';
import * as rules from 'vee-validate/dist/rules';
import router from './router'
import authenticator from './services/authenticator';

Vue.use(BootstrapVue);
Vue.use(BootstrapVueIcons);

Object.keys(rules).forEach(rule => {
  extend(rule, rules[rule]);
});

extend("required", {
  validate(value) {
    return {
      required: true,
      valid: ["", null, undefined, false].indexOf(value) === -1,
    };
  },
  computesRequired: true,
  message: "This field is required",
});

localize('en', en);

Vue.component('ValidationObserver', ValidationObserver);
Vue.component('ValidationProvider', ValidationProvider);

var unregister = fetchIntercept.register({
  request: function (url, config) {
    // Modify the url or config here
    if (new RegExp('api/products').test(url)) {
      config.headers['x-access-token'] = authenticator.getToken();
    }
    return [url, config];
  },

  requestError: function (error) {
    // Called when an error occured during another 'request' interceptor call
    return Promise.reject(error);
  },

  response: function (response) {
    // Modify the reponse object
    return response;
  },

  responseError: function (error) {
    // Handle an fetch error
    return Promise.reject(error);
  }
});

Vue.config.productionTip = false;

new Vue({
  router,
  render: (h) => h(App),
  destroyed() {
    unregister();
  }
}).$mount("#app");