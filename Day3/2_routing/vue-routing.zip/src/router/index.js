import Vue from 'vue';
import VueRouter from 'vue-router';

import authenticator from '../services/authenticator';

// Eager Loading
import Home from '../views/Home.vue';
// import About from '../views/About.vue';
import Products from '../views/Products.vue';
import ViewNotFound from '../views/ViewNotFound.vue';
// import Admin from '../views/Admin.vue';

// import LoginComponent from '../components/login/LoginComponent.vue';

import ProductDetails from '../components/products/ProductDetails.vue';
import ProductNotSelected from '../components/products/ProductNotSelected.vue';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: Home
  },
  // {
  //   path: '/about',
  //   name: 'About',
  //   component: About
  // },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  },
  {
    path: '/products',
    component: Products,
    children: [
      {
        path: ':productId',
        name: 'ProductIdLink',
        component: ProductDetails
      },
      {
        path: '',
        component: ProductNotSelected
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../components/login/LoginComponent.vue')
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('../views/Admin.vue'),
    beforeEnter: (to, from, next) => {
      if (!authenticator.isAuthenticated) {
        next({
          name: "Login",
          query: { redirectFrom: to.fullPath }
        });
      }
      else {
        next();
      }
    }
  },
  {
    path: '*',
    component: ViewNotFound
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
