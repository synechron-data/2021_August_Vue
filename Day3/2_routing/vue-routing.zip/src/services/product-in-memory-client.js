const productsData = [
    {
        id: 1,
        name: "Item One",
        description:
            "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        status: "Available",
    },
    {
        id: 2,
        name: "Item Two",
        description: "sunt aut facere ptio reprehenderit",
        status: "Not Available",
    },
    {
        id: 3,
        name: "Item Three",
        description: "provident occaecati excepturi optio reprehenderit",
        status: "Available",
    },
    {
        id: 4,
        name: "Item Four",
        description: "reprehenderit",
        status: "Not Available",
    },
];

const productInMemoryClient = {
    getAllProducts: function () {
        return productsData;
    },
    getProductById: function (id) {
        return productsData.find(p => p.id === parseInt(id));
    },
};

export default productInMemoryClient;