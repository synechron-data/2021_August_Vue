<template>
	<admin-component />
</template>

<script>
	import AdminComponent from "../components/admin/AdminComponent.vue";
	export default {
		components: { AdminComponent },
		name: "AdminView",
	};
</script>
