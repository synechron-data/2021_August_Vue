<template>
	<div class="container">
		<navigation-component />
		<div class="mt-5">
			<router-view />
		</div>
	</div>
</template>

<script>
	import NavigationComponent from "./components/bs-nav/NavigationComponent.vue";
	/* eslint-disable */
	export default {
		name: "App",
		components: {
			NavigationComponent,
		},
	};
</script>,