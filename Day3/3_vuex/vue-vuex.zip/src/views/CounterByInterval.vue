<template>
	<div>
		<h2 class="text-primary text-center">Counter By Interval Component</h2>
		<div class="row">
			<div class="col-4">
				<div class="form-group">
					<label>Set Interval</label>
					<input type="number" class="form-control" v-model.number="interval" />
				</div>
			</div>
		</div>

		<h3>Count:</h3>
		<button class="btn btn-primary">+</button>
		<button class="btn btn-primary">-</button>
	</div>
</template>

<script>
	export default {
		name: "CounterByInterval",
		data() {
			return {
				interval: 1,
			};
		},
		computed: {},
		methods: {},
	};
</script>
