<template>
	<div>
		<counter-component />
		<hr />
		<counter-sibling />
	</div>
</template>

<script>
	import CounterComponent from "../components/counter/CounterComponent.vue";
	import CounterSibling from "../components/counter/CounterSibling.vue";
	export default {
		components: { CounterComponent, CounterSibling },
		name: "CounterView",
	};
</script>
