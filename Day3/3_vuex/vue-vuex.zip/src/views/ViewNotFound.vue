<template>
	<article>
		<h1 class="text-danger">No Route Configured!</h1>
		<h4 class="text-danger">Please check your Route Configuration</h4>
	</article>
</template>

<script>
	export default {
		name: "ViewNotFound",
	};
</script>