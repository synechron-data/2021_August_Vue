import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';
import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue';

import Vue from 'vue'

import App from './App.vue';
import { ValidationObserver, ValidationProvider, extend, localize } from 'vee-validate';
import en from 'vee-validate/dist/locale/en.json';
import * as rules from 'vee-validate/dist/rules';
import router from './router';
import store from './store';

Vue.use(BootstrapVue);
Vue.use(BootstrapVueIcons);

Object.keys(rules).forEach(rule => {
  extend(rule, rules[rule]);
});

extend("required", {
  validate(value) {
    return {
      required: true,
      valid: ["", null, undefined, false].indexOf(value) === -1,
    };
  },
  computesRequired: true,
  message: "This field is required",
});

localize('en', en);

Vue.component('ValidationObserver', ValidationObserver);
Vue.component('ValidationProvider', ValidationProvider);

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount("#app");