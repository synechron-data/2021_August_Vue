import productApiClient from '../../services/product-api-client';

export default {
    state: {
        status: "",
        flag: true,
        items: [],
    },
    mutations: {
        getProducts(state, data) {
            state.items = data;
        }
    },
    actions: {
        async getProductsAction({ commit }) {
            const data = await productApiClient.getAllProducts();
            commit('getProducts', data);
        }
    }
};