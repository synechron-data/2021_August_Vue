<template>
	<div>
        <h2 class="text-success text-center">Counter Sibling</h2>
		<h3>Count: {{ count }}</h3>
		<button class="btn btn-success" @click="inc">+</button>
		<button class="btn btn-success" @click="dec">-</button>
	</div>
</template>

<script>
	export default {
		name: "CounterSibling",
		computed: {
			count() {
				// return this.$store.state.count;
				return this.$store.state.counter.count;
			},
		},
        methods: {
            inc() {
                this.$store.commit('increment');
            },
            dec(){
                this.$store.commit('decrement');
            }
        },
	};
</script>
