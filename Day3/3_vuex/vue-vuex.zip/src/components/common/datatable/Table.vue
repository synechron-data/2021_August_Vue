<template>
	<table class="table table-striped table-hover">
		<thead class="thead-dark">
			<table-header :header="tableHeaders" />
		</thead>
		<tbody>
			<table-row v-for="(row, $index) in tableRows" :key="$index" :row="row" />
		</tbody>
	</table>
</template>

<script>
	/* eslint-disable */
	import TableHeader from "./TableHeader.vue";
	import TableRow from "./TableRow.vue";
	export default {
		components: { TableHeader, TableRow },
		name: "DataTable",
		props: {
			items: {
				type: Array,
				required: true,
			},
		},
		computed: {
			tableHeaders() {
				if (this.items.length > 0) {
					return Object.keys(this.items[0]).map((header, index) => {
						return {
							index: index,
							identifier: header.toUpperCase(),
						};
					});
				} else return null;
			},
			tableRows() {
				if (this.items.length > 0)
					return this.items.map((obj, idx) => {
						return Object.keys(obj).map((key, idx2) => {
							return {
								key: key,
								value: Object.values(obj)[idx2],
							};
						});
					});
				else return null;
			},
		},
	};
</script>