module.exports = {
    devServer: {
        open: true
    },
};