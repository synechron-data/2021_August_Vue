<template>
	<div class="container">
		<!-- <form-validation /> -->
		<ajax-component />
	</div>
</template>

<script>
	import FormValidation from "./components/1_form-validation/FormValidation.vue";
	import AjaxComponent from "./components/2_ajax/AjaxComponent.vue";
	/* eslint-disable */
	export default {
		name: "App",
		components: {
			FormValidation,
			AjaxComponent,
		},
	};
</script>,