<template>
	<form class="form-horizontal">
		<fieldset class="form-group border p-3">
			<legend class="w-auto px-2 text-center">
				<h3>Form with Custom Validation</h3>
			</legend>
			<div class="form-group">
				<label for="firstname" class="mb-1">
					<h6 class="mb-0 text-sm">Firstname</h6>
				</label>
				<input
					type="text"
					class="form-control"
					id="firstname"
					name="firstName"
				/>
			</div>
			<div class="form-group">
				<label for="lastname" class="mb-1">
					<h6 class="mb-0 text-sm">Lastname</h6>
				</label>
				<input type="text" class="form-control" id="lastname" name="lastname" />
			</div>
			<div class="form-group">
				<label for="gender" class="mb-1">
					<h6 class="mb-0 text-sm">Gender</h6>
				</label>
				<div>
					<div class="form-check-inline">
						<input
							class="form-check-input"
							type="radio"
							id="gender"
							value="male"
						/>
						<label class="form-check-label" for="gender"> Male </label>
					</div>
					<div class="form-check-inline">
						<input
							class="form-check-input"
							type="radio"
							id="gender"
							value="female"
						/>
						<label class="form-check-label" for="gender"> Female </label>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label for="country" class="mb-1">
					<h6 class="mb-0 text-sm">Country</h6>
				</label>
				<select class="form-control" id="country">
					<option
						v-for="country of countries"
						:value="country.id"
						:key="country.id"
					>
						{{ country.name }}
					</option>
				</select>
			</div>
			<div class="form-group">
				<label for="city" class="mb-1">
					<h6 class="mb-0 text-sm">City</h6>
				</label>
				<input type="text" class="form-control" id="city" />
			</div>
			<div class="form-group">
				<label for="zip" class="mb-1">
					<h6 class="mb-0 text-sm">Zip</h6>
				</label>
				<input type="text" class="form-control" id="zip" />
			</div>
			<div class="form-group form-check">
				<input type="checkbox" class="form-check-input" id="acceptTerms" />
				<label for="acceptTerms" class="form-check-label">
					<h6 class="mb-0 text-sm">Agree to terms and conditions</h6>
				</label>
			</div>
			<div class="form-group row">
				<div class="col">
					<button type="submit" class="btn btn-primary btn-block">Save</button>
				</div>
				<div class="col">
					<button type="button" class="btn btn-secondary btn-block">
						Reset
					</button>
				</div>
			</div>
		</fieldset>
	</form>
</template>

<script>
	export default {
		name: "FormValidation",
		data: function () {
			this.countries = [
				{ id: "", name: "Select Country" },
				{ id: 1, name: "India" },
				{ id: 2, name: "USA" },
				{ id: 3, name: "UK" },
			];
			return {
				regForm: {
					firstname: "",
					lastname: "",
					gender: "",
					address: {
						country: "",
						city: "",
						zip: "",
					},
					acceptTerms: false,
				},
			};
		},
		methods: {
			onSubmit() {
				console.log("Success !!");
				console.log(JSON.stringify(this.regForm));
			},
		},
	};
</script>