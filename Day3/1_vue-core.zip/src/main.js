import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';

import Vue from 'vue'

import App from './App.vue';
// npm i vee-validate
import { ValidationObserver, ValidationProvider, extend, localize } from 'vee-validate';
import en from 'vee-validate/dist/locale/en.json';
import * as rules from 'vee-validate/dist/rules';

Object.keys(rules).forEach(rule => {
  // console.log(rule);
  extend(rule, rules[rule]);
});

extend("required", {
  validate(value) {
    return {
      required: true,
      valid: ["", null, undefined, false].indexOf(value) === -1,
    };
  },
  computesRequired: true,
  message: "This field is required",
});

localize('en', en);

Vue.component('ValidationObserver', ValidationObserver);
Vue.component('ValidationProvider', ValidationProvider);

Vue.config.productionTip = false;

new Vue({
  render: (h) => h(App)
}).$mount("#app");