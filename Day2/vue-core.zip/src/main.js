import 'bootstrap/scss/bootstrap.scss';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap';

import Vue from 'vue'
import App from './App.vue';
import demoDirective from './directives/demo.directive';
import changeContent from './directives/changeContent.directive';
import highlightDirective from './directives/highlight.directive';

Vue.config.productionTip = false;

// Global Mixin
Vue.mixin({
  created: function () {
    console.log("Vue Created...", this);
  }
});

// Global Filter
Vue.filter('JSON', function (value) {
  return JSON.stringify(value);
});

// Global Directives
Vue.directive('demo', demoDirective);
Vue.directive('cc', changeContent);
Vue.directive('highlight', highlightDirective);

new Vue({
  render: (h) => h(App)
}).$mount("#app");