const changeContent = {
    bind: function (el) {
        el.innerHTML = "Content Added By the Custom Directive";
    }
};

export default changeContent;