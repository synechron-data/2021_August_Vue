<template>
	<div class="container">
		<!-- <prop-root /> -->
		<!-- <behavior-root /> -->
		<!-- <event-component /> -->
		<!-- <binding-component /> -->
		<!-- <calculator-assignment /> -->
		<!-- <counter-assignment /> -->
		<!-- <slot-root /> -->
		<!-- <dynamic-root /> -->
		<!-- <mixin-root /> -->
		<!-- <filter-demo /> -->
		<custom-directives />
	</div>
</template>

<script>
	import PropRoot from "./components/1_comp-props/PropRoot.vue";
	import BehaviorRoot from "./components/2_comp-methods/BehaviorRoot.vue";
	import EventComponent from "./components/3_event-handling/EventComponent.vue";
	import BindingComponent from "./components/4_two-way-binding/BindingComponent.vue";
	import CalculatorAssignment from "./components/5_calculator-assignment/CalculatorAssignment.vue";
	import CounterAssignment from "./components/6_counter-assignment/CounterAssignment.vue";
	import SlotRoot from "./components/7_slots/SlotRoot.vue";
	import DynamicRoot from "./components/8_dynamic-components/DynamicRoot.vue";
	import MixinRoot from "./components/9_mixins/MixinRoot.vue";
	import FilterDemo from "./components/10_filters/FilterDemo.vue";
	import CustomDirectives from "./components/11_custom-directives/CustomDirectives.vue";
	/* eslint-disable */
	export default {
		name: "App",
		components: {
			PropRoot,
			BehaviorRoot,
			EventComponent,
			BindingComponent,
			CalculatorAssignment,
			CounterAssignment,
			SlotRoot,
			DynamicRoot,
			MixinRoot,
			FilterDemo,
			CustomDirectives,
		},
	};
</script>,