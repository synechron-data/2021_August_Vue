<template>
	<div>
		<h1 class="text-success">Hello from Component Two</h1>
	</div>
</template>

<script>
	export default {
		name: "ComponentTwo",
		destroyed: function () {
			console.log("Component Two Destroyed");
		},
	};
</script>