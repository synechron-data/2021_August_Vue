<template>
	<div>
		<h1 class="text-primary">Component With Behavior</h1>
		<h2 class="text-info">Id: {{ id }}</h2>
		<h2 class="text-info">Count: {{ count }}</h2>
		<div class="row">
			<div class="col">
				<button class="btn btn-primary btn-block" v-on:click="changeCount1">
					Click
				</button>
			</div>
			<div class="col">
				<button class="btn btn-primary btn-block" @click="changeCount2">
					Click
				</button>
			</div>
		</div>
		<hr />
		<h2>Props Area</h2>
		<h2 class="text-info">Name: {{ name }}</h2>
		<h2 class="text-info">Address: {{ address }}</h2>
		<h2>Data(State) Area</h2>
		<h2 class="text-info">Name: {{ sname }}</h2>
		<h2 class="text-info">Address: {{ saddress }}</h2>
		<div class="row">
			<div class="col">
				<button class="btn btn-primary btn-block" @click="handleChange">
					Click to Change
				</button>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		name: "ComponentWithBehavior",
		data: function () {
			return {
				id: 1,
				count: 0,
				sname: this.name,
				saddress: { ...this.address },
			};
		},
		props: {
			name: {
				type: String,
				default: "No Name",
			},
			address: {
				type: Object,
				require: true,
			},
		},
		methods: {
			changeCount1() {
				this.count += 1;
			},
			changeCount2: function () {
				this.count += 1;
			},
			handleChange: function () {
				// Props should be treated as readonly
				// Avoid mutating a prop directly since the value will be overwritten whenever the parent component re-renders.
				// Instead, use a data or computed property based on the prop's value.
				// this.name = "Abhijeet";
				// this.address.city = "Mumbai";

				// Always Change or Modify State (data())
				this.sname = "Abhijeet";
				this.saddress.city = "Mumbai";
			},
		},
	};
</script>